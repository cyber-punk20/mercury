---
layout: page
title: fi_mlx(7)
tagline: Libfabric Programmer's Manual
---
{% include JB/setup %}

# NAME

fi_mlx \- The MLX Fabric Provider

# OVERVIEW

The mlx provider was deprecated and removed in libfabric 1.9
due to a lack of a maintainer.

# SEE ALSO

[`fabric`(7)](fabric.7.html),
[`fi_provider`(7)](fi_provider.7.html),
