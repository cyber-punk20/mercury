
#ifndef _FI_WIN_NETINET_IN_H_
#define _FI_WIN_NETINET_IN_H_

#include <WinSock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#endif /* _FI_WIN_NETINET_IN_H_ */
